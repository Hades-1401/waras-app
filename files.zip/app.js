/* ═══════════════════════════════════════════════════════════════════════════
   نور الوِلادة — Nūr al-Wilādah
   Dawoodi Bohra Misri Calendar Birthday Manager
   Static build for GitHub Pages — React 18 via CDN
   ═══════════════════════════════════════════════════════════════════════════ */

var { useState, useEffect, useMemo, useCallback, useRef } = React;

// ============================================================================
// MISRI CALENDAR ENGINE
// ============================================================================

var MISRI_MONTHS = [
  "Moharram al-Haraam","Safar al-Muzaffar","Rabi al-Awwal","Rabi al-Aakhar",
  "Jumada al-Ula","Jumada al-Ukhra","Rajab al-Asabb","Shabaan al-Karim",
  "Ramadaan al-Moazzam","Shawwal al-Mukarram","Zilqad al-Haraam","Zilhaj al-Haraam"
];

var MISRI_MONTHS_SHORT = [
  "Moharram","Safar","Rabi I","Rabi II","Jumada I","Jumada II",
  "Rajab","Shabaan","Ramadaan","Shawwal","Zilqad","Zilhaj"
];

var LEAP_YEARS = [2,5,7,10,13,16,18,21,24,26,29];
var CYCLE_DAYS = 10631;
var MISRI_EPOCH_JD = 1948439;

function isLeapMisriYear(y) {
  return LEAP_YEARS.indexOf(((y-1)%30)+1) !== -1;
}
function misriYearDays(y) { return isLeapMisriYear(y) ? 355 : 354; }
function misriMonthDays(m, y) {
  if (m === 12) return isLeapMisriYear(y) ? 30 : 29;
  return m % 2 === 1 ? 30 : 29;
}
function gregorianToJD(y, m, d) {
  var a = Math.floor((14 - m) / 12);
  var yy = y + 4800 - a;
  var mm = m + 12 * a - 3;
  return d + Math.floor((153*mm+2)/5) + 365*yy + Math.floor(yy/4) - Math.floor(yy/100) + Math.floor(yy/400) - 32045;
}
function gregorianToMisri(date) {
  var jd = gregorianToJD(date.getFullYear(), date.getMonth()+1, date.getDate());
  var dse = jd - MISRI_EPOCH_JD;
  var cycles = Math.floor(dse / CYCLE_DAYS);
  var rem = dse - cycles * CYCLE_DAYS;
  var yic = 0;
  for (var yy = 1; yy <= 30; yy++) {
    var yd = LEAP_YEARS.indexOf(yy) !== -1 ? 355 : 354;
    if (rem < yd) { yic = yy; break; }
    rem -= yd;
  }
  var misriYear = cycles * 30 + yic;
  var misriMonth = 1;
  for (var mm = 1; mm <= 12; mm++) {
    var md = mm === 12 ? (LEAP_YEARS.indexOf(yic)!==-1 ? 30 : 29) : (mm%2===1 ? 30 : 29);
    if (rem < md) { misriMonth = mm; break; }
    rem -= md;
  }
  return { year: misriYear, month: misriMonth, day: rem + 1 };
}
function todayMisri() { return gregorianToMisri(new Date()); }
function getMisriDateInNDays(n) {
  var d = new Date(); d.setDate(d.getDate()+n); return gregorianToMisri(d);
}
function formatMisriDate(day, month, year) {
  var mn = MISRI_MONTHS_SHORT[month-1] || "";
  return year ? day+" "+mn+" "+year : day+" "+mn;
}

// ============================================================================
// ITS52 AUTH (mock)
// ============================================================================

function authenticateWithITS52(itsId, password) {
  return new Promise(function(resolve, reject) {
    setTimeout(function() {
      if (itsId && password && password.length >= 4) {
        resolve({
          success: true,
          user: { id: "u_"+itsId, its_id: itsId, name: "Mumineen User", email: itsId+"@its52.com" },
          token: btoa(JSON.stringify({ itsId: itsId, ts: Date.now() }))
        });
      } else {
        reject({ success: false, error: "Invalid ITS ID or password" });
      }
    }, 800);
  });
}

// ============================================================================
// DATA STORE
// ============================================================================

function loadContacts(uid) {
  try { return JSON.parse(localStorage.getItem("nw_contacts_"+uid) || "[]"); }
  catch(e) { return []; }
}
function saveContacts(uid, c) {
  localStorage.setItem("nw_contacts_"+uid, JSON.stringify(c));
}

// ============================================================================
// MESSAGE GENERATOR
// ============================================================================

var MESSAGES = {
  english: [
    function(n,r,d){ return "Wishing "+n+" a very happy Misri birthday on "+d+"! May this year bring immense joy and barakaat."; },
    function(n,r,d){ return "Happy Misri Birthday, "+n+"! On this blessed day of "+d+", may Allah Ta\u2019ala grant you happiness and good health."; },
    function(n,r,d){ return "Dearest "+n+", celebrating your special day \u2014 "+d+". May Aqa Moula\u2019s dua always be with you!"; },
  ],
  mixed: [
    function(n,r,d){ return "Mubarak ho "+n+"! Aapni Misri birthday \u2014 "+d+" \u2014 par khushi aur salamati ni dua. Khuda Ta\u2019ala aapne hamesha khush rakhey. \uD83C\uDF19"; },
    function(n,r,d){ return "Ya Allah, "+n+" ne "+d+" ni Misri birthday mubarak! Aqa Moula TUS ni dua sadaa saathe rahey. Saal mubarak! \u2728"; },
    function(n,r,d){ return n+", aapni janam-tithi "+d+" par bahot bahot mubarak! May you be blessed with afiyat and khushi. \uD83E\uDD32"; },
  ],
  arabic: [
    function(n,r,d){ return "\u0628\u0627\u0631\u0643 \u0627\u0644\u0644\u0647 \u0641\u064A \u0639\u0645\u0631\u0643 \u064A\u0627 "+n+"! \u0639\u064A\u062F \u0645\u064A\u0644\u0627\u062F \u0633\u0639\u064A\u062F \u0641\u064A "+d+". \u0627\u0644\u0644\u0647\u0645 \u0627\u062D\u0641\u0638\u0647 \u0628\u062F\u0639\u0627\u0621 \u0645\u0648\u0644\u0627\u0646\u0627. \uD83C\uDF1F"; },
    function(n,r,d){ return "\u0643\u0644 \u0639\u0627\u0645 \u0648\u0623\u0646\u062A \u0628\u062E\u064A\u0631 \u064A\u0627 "+n+"! \u0645\u064A\u0644\u0627\u062F\u0643 \u0627\u0644\u0645\u0635\u0631\u064A "+d+" \u0645\u0628\u0627\u0631\u0643. \uD83E\uDD32"; },
  ]
};

function generateMessage(name, rel, mDay, mMonth, lang) {
  var md = formatMisriDate(mDay, mMonth);
  var pool = MESSAGES[lang||"mixed"] || MESSAGES.mixed;
  return pool[Math.floor(Math.random()*pool.length)](name, rel, md);
}

// ============================================================================
// COLORS & STYLE HELPERS
// ============================================================================

var C = {
  navy: "#0A1628", navyLight: "#0F1F3D", navyMid: "#142952",
  gold: "#D4AF37", goldLight: "#E8D48B", goldDark: "#B8941E",
  goldMetal: "linear-gradient(135deg, #D4AF37 0%, #F5E7A3 40%, #D4AF37 60%, #AA8A2A 100%)",
  cream: "#FAF6EE", white: "#FFFFFF",
  textDark: "#1A1A2E", textMuted: "#6B7280",
  danger: "#DC2626", success: "#059669",
};

function tag(color) {
  color = color || C.gold;
  return {
    display:"inline-block", padding:"3px 10px", borderRadius:"20px",
    fontSize:"11px", fontWeight:"600", background: color+"18",
    color: color, border:"1px solid "+color+"30",
    textTransform:"uppercase", letterSpacing:"0.5px",
  };
}

// ============================================================================
// SMALL COMPONENTS
// ============================================================================

function GeoBorder() {
  return React.createElement("div", { style: {
    height:"4px", position:"relative", margin:"0 0 24px",
    background:"linear-gradient(90deg, transparent 0%, #C5A54E 15%, #D4AF37 50%, #C5A54E 85%, transparent 100%)",
  }},
    React.createElement("div", { style: {
      position:"absolute", top:"-3px", left:"50%",
      width:"10px", height:"10px", background:"#D4AF37",
      transform:"translateX(-50%) rotate(45deg)",
    }})
  );
}

var RELATIONSHIPS = ["Family","Friend","Community","Teacher/Mentor","Colleague","Other"];

// ============================================================================
// LOGIN PAGE
// ============================================================================

function LoginPage(props) {
  var _s = useState(""), itsId = _s[0], setItsId = _s[1];
  var _p = useState(""), password = _p[0], setPassword = _p[1];
  var _l = useState(false), loading = _l[0], setLoading = _l[1];
  var _e = useState(""), error = _e[0], setError = _e[1];
  var _f = useState(null), focused = _f[0], setFocused = _f[1];

  function handleSubmit(e) {
    e.preventDefault(); setError(""); setLoading(true);
    authenticateWithITS52(itsId, password).then(function(r) {
      props.onLogin(r.user, r.token);
    }).catch(function(err) {
      setError(err.error || "Authentication failed.");
    }).finally(function() { setLoading(false); });
  }

  var inputBase = {
    width:"100%", padding:"12px 16px", background:"rgba(255,255,255,0.06)",
    border:"1px solid rgba(212,175,55,0.2)", borderRadius:"8px",
    color:"#fff", fontSize:"15px", boxSizing:"border-box",
    transition:"border-color 0.3s, box-shadow 0.3s",
  };
  var inputFocus = { borderColor: C.gold, boxShadow:"0 0 0 3px rgba(212,175,55,0.15)" };

  return React.createElement("div", { style: {
    minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
    background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyLight+" 50%, "+C.navyMid+" 100%)",
    position:"relative", overflow:"hidden",
  }},
    React.createElement("div", { className:"fatimid-bg" }),
    // Decorative orbs
    React.createElement("div", { style: {
      position:"absolute",top:"-120px",right:"-80px",width:"400px",height:"400px",
      borderRadius:"50%",background:"radial-gradient(circle, rgba(212,175,55,0.08) 0%, transparent 70%)",
    }}),
    React.createElement("div", { style: {
      position:"absolute",bottom:"-150px",left:"-100px",width:"500px",height:"500px",
      borderRadius:"50%",background:"radial-gradient(circle, rgba(212,175,55,0.06) 0%, transparent 70%)",
    }}),
    // Login card
    React.createElement("div", { style: {
      background:"rgba(255,255,255,0.03)", backdropFilter:"blur(20px)",
      border:"1px solid rgba(212,175,55,0.3)", borderRadius:"16px",
      padding:"48px 40px", width:"100%", maxWidth:"420px",
      position:"relative", zIndex:2,
      boxShadow:"0 25px 60px rgba(0,0,0,0.5), inset 0 1px 0 rgba(212,175,55,0.15)",
    }},
      React.createElement("div", { style:{textAlign:"center",marginBottom:"8px",fontSize:"24px"} }, "\uD83C\uDF19"),
      React.createElement("div", { style:{textAlign:"center",marginBottom:"20px"} },
        React.createElement("span", { style:{color:C.gold,fontSize:"11px",letterSpacing:"4px",textTransform:"uppercase",fontWeight:"600"} },
          "\u2726 \u0646\u0648\u0631 \u0627\u0644\u0648\u0650\u0644\u0627\u062F\u0629 \u2726"
        )
      ),
      React.createElement("h1", { style:{fontSize:"28px",fontWeight:"700",color:C.gold,textAlign:"center",marginBottom:"4px",letterSpacing:"1px"} },
        "N\u016Br al-Wil\u0101dah"
      ),
      React.createElement("p", { style:{fontSize:"14px",color:"rgba(255,255,255,0.5)",textAlign:"center",marginBottom:"32px",fontStyle:"italic"} },
        "Light of Birth \u2014 Misri Waras Mubarak"
      ),
      React.createElement(GeoBorder),
      error && React.createElement("div", { style:{
        background:"rgba(220,38,38,0.15)",color:"#FCA5A5",padding:"10px 14px",
        borderRadius:"8px",fontSize:"13px",marginBottom:"16px",
        border:"1px solid rgba(220,38,38,0.3)",
      }}, error),
      React.createElement("form", { onSubmit: handleSubmit },
        React.createElement("div", { style:{marginBottom:"20px"} },
          React.createElement("label", { style:{display:"block",fontSize:"12px",fontWeight:"600",color:C.goldLight,marginBottom:"6px",textTransform:"uppercase",letterSpacing:"1.5px"} }, "ITS ID (8-digit)"),
          React.createElement("input", {
            type:"text", value:itsId, onChange:function(e){setItsId(e.target.value);},
            onFocus:function(){setFocused("its");}, onBlur:function(){setFocused(null);},
            placeholder:"Enter your ITS ID", maxLength:8, required:true,
            style: Object.assign({}, inputBase, focused==="its" ? inputFocus : {}),
          })
        ),
        React.createElement("div", { style:{marginBottom:"20px"} },
          React.createElement("label", { style:{display:"block",fontSize:"12px",fontWeight:"600",color:C.goldLight,marginBottom:"6px",textTransform:"uppercase",letterSpacing:"1.5px"} }, "Password"),
          React.createElement("input", {
            type:"password", value:password, onChange:function(e){setPassword(e.target.value);},
            onFocus:function(){setFocused("pw");}, onBlur:function(){setFocused(null);},
            placeholder:"Enter your password", required:true,
            style: Object.assign({}, inputBase, focused==="pw" ? inputFocus : {}),
          })
        ),
        React.createElement("button", {
          type:"submit", disabled:loading, className:"btn-gold",
          style:{
            width:"100%",padding:"14px",background:C.goldMetal,color:C.navy,
            border:"none",borderRadius:"8px",fontSize:"15px",fontWeight:"700",
            cursor:"pointer",letterSpacing:"1px",textTransform:"uppercase",
            opacity: loading ? 0.7 : 1,
          }
        }, loading ? "Authenticating\u2026" : "Sign In with ITS52")
      ),
      React.createElement("p", { style:{textAlign:"center",fontSize:"11px",color:"rgba(255,255,255,0.3)",marginTop:"20px"} },
        "Secure authentication via ITS52 \u2022 Your data is encrypted"
      )
    )
  );
}

// ============================================================================
// CONTACT FORM MODAL
// ============================================================================

function ContactModal(props) {
  var c = props.contact;
  var _n = useState(c ? c.name : ""), name = _n[0], setName = _n[1];
  var _r = useState(c ? c.relationship : "Family"), rel = _r[0], setRel = _r[1];
  var _d = useState(c ? c.gregorian_dob : ""), dob = _d[0], setDob = _d[1];
  var _nt = useState(c ? c.notes||"" : ""), notes = _nt[0], setNotes = _nt[1];
  var _mp = useState(null), misriP = _mp[0], setMisriP = _mp[1];

  useEffect(function() {
    if (dob) {
      var d = new Date(dob+"T00:00:00");
      if (!isNaN(d.getTime())) setMisriP(gregorianToMisri(d));
    } else { setMisriP(null); }
  }, [dob]);

  function handleSave() {
    if (!name.trim() || !dob) return;
    var d = new Date(dob+"T00:00:00");
    var m = gregorianToMisri(d);
    props.onSave({
      id: c ? c.id : "c_"+Date.now(), name:name.trim(), relationship:rel,
      gregorian_dob:dob, misri_day:m.day, misri_month:m.month, misri_year_born:m.year,
      notes:notes.trim(), created_at: c?c.created_at:new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });
  }

  var fi = { width:"100%",padding:"10px 14px",border:"1px solid #d1d5db",borderRadius:"8px",fontSize:"14px",boxSizing:"border-box" };
  var fl = { display:"block",fontSize:"13px",fontWeight:"600",color:C.textDark,marginBottom:"6px" };

  return React.createElement("div", {
    onClick: props.onClose,
    style:{position:"fixed",inset:0,background:"rgba(10,22,40,0.7)",backdropFilter:"blur(4px)",
      display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000}
  },
    React.createElement("div", { onClick:function(e){e.stopPropagation();}, style:{
      background:C.white,borderRadius:"16px",border:"1px solid rgba(212,175,55,0.2)",
      boxShadow:"0 25px 60px rgba(0,0,0,0.3)",width:"100%",maxWidth:"500px",maxHeight:"90vh",overflow:"auto",
    }},
      // Header
      React.createElement("div", { style:{padding:"20px 24px",background:C.navy,color:C.gold,borderRadius:"16px 16px 0 0",display:"flex",justifyContent:"space-between",alignItems:"center"} },
        React.createElement("h3", { style:{margin:0,fontSize:"18px",fontWeight:"600"} }, c ? "Edit Contact" : "Add New Contact"),
        React.createElement("button", { onClick:props.onClose, style:{background:"none",border:"none",color:C.goldLight,cursor:"pointer",fontSize:"20px"} }, "\u2715")
      ),
      // Body
      React.createElement("div", { style:{padding:"24px"} },
        React.createElement("div", {style:{marginBottom:"18px"}},
          React.createElement("label", {style:fl}, "Full Name *"),
          React.createElement("input", {type:"text",value:name,onChange:function(e){setName(e.target.value);},placeholder:"e.g. Mulla Husain bhai",style:fi})
        ),
        React.createElement("div", {style:{marginBottom:"18px"}},
          React.createElement("label", {style:fl}, "Relationship"),
          React.createElement("select", {value:rel,onChange:function(e){setRel(e.target.value);},style:Object.assign({},fi,{cursor:"pointer"})},
            RELATIONSHIPS.map(function(r){return React.createElement("option",{key:r,value:r},r);})
          )
        ),
        React.createElement("div", {style:{marginBottom:"18px"}},
          React.createElement("label", {style:fl}, "Gregorian Date of Birth *"),
          React.createElement("input", {type:"date",value:dob,onChange:function(e){setDob(e.target.value);},style:fi})
        ),
        misriP && React.createElement("div", { style:{
          background:"linear-gradient(135deg, rgba(212,175,55,0.08), rgba(212,175,55,0.02))",
          border:"1px solid rgba(212,175,55,0.25)",borderRadius:"10px",padding:"14px 18px",marginBottom:"18px",
        }},
          React.createElement("div", {style:{fontSize:"12px",color:C.textMuted,fontWeight:"600",textTransform:"uppercase",letterSpacing:"1px",marginBottom:"4px"}}, "Misri Birthday"),
          React.createElement("div", {style:{fontSize:"20px",fontWeight:"700",color:C.goldDark}}, formatMisriDate(misriP.day, misriP.month)),
          React.createElement("div", {style:{fontSize:"12px",color:C.textMuted,marginTop:"2px"}}, "Born in Misri year "+misriP.year)
        ),
        React.createElement("div", {style:{marginBottom:"24px"}},
          React.createElement("label", {style:fl}, "Notes (optional)"),
          React.createElement("textarea", {value:notes,onChange:function(e){setNotes(e.target.value);},placeholder:"Any special notes\u2026",rows:3,style:Object.assign({},fi,{resize:"vertical"})})
        ),
        React.createElement("div", {style:{display:"flex",gap:"12px",justifyContent:"flex-end"}},
          React.createElement("button", {onClick:props.onClose,className:"btn-sm",style:{padding:"10px 24px",borderRadius:"8px",border:"1px solid #d1d5db",background:"transparent",color:C.textMuted,cursor:"pointer",fontSize:"13px",fontWeight:"600"}}, "Cancel"),
          React.createElement("button", {onClick:handleSave,disabled:!name.trim()||!dob,className:"btn-gold btn-sm",style:{
            padding:"10px 24px",borderRadius:"8px",border:"none",background:C.goldMetal,
            color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600",
            opacity:(!name.trim()||!dob)?0.5:1,
          }}, c ? "Update Contact" : "Add Contact")
        )
      )
    )
  );
}

// ============================================================================
// MESSAGE MODAL
// ============================================================================

function MessageModal(props) {
  var ct = props.contact;
  var _m = useState(""), msg = _m[0], setMsg = _m[1];
  var _c = useState(false), copied = _c[0], setCopied = _c[1];

  useEffect(function() {
    if (ct) setMsg(generateMessage(ct.name, ct.relationship, ct.misri_day, ct.misri_month, props.langPref));
  }, [ct, props.langPref]);

  function regen() {
    setMsg(generateMessage(ct.name, ct.relationship, ct.misri_day, ct.misri_month, props.langPref));
    setCopied(false);
  }
  function copyMsg() {
    navigator.clipboard.writeText(msg).then(function(){ setCopied(true); setTimeout(function(){setCopied(false);},2000); });
  }

  return React.createElement("div", {
    onClick:props.onClose,
    style:{position:"fixed",inset:0,background:"rgba(10,22,40,0.7)",backdropFilter:"blur(4px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000}
  },
    React.createElement("div", {onClick:function(e){e.stopPropagation();},style:{
      background:C.white,borderRadius:"16px",border:"1px solid rgba(212,175,55,0.2)",
      boxShadow:"0 25px 60px rgba(0,0,0,0.3)",width:"100%",maxWidth:"520px",maxHeight:"90vh",overflow:"auto",
    }},
      React.createElement("div", {style:{padding:"20px 24px",background:C.navy,color:C.gold,borderRadius:"16px 16px 0 0",display:"flex",justifyContent:"space-between",alignItems:"center"}},
        React.createElement("h3", {style:{margin:0,fontSize:"18px"}}, "\uD83C\uDF89 Birthday Message"),
        React.createElement("button", {onClick:props.onClose,style:{background:"none",border:"none",color:C.goldLight,cursor:"pointer",fontSize:"20px"}}, "\u2715")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        React.createElement("div", {style:{marginBottom:"12px"}},
          React.createElement("span", {style:{fontSize:"13px",color:C.textMuted}}, "For "),
          React.createElement("span", {style:{fontWeight:"700",color:C.textDark}}, ct.name),
          React.createElement("span", {style:{fontSize:"13px",color:C.textMuted}}, " \u2014 "+formatMisriDate(ct.misri_day,ct.misri_month))
        ),
        React.createElement("div", {style:{
          background:"linear-gradient(135deg, rgba(212,175,55,0.05) 0%, rgba(250,246,238,1) 100%)",
          border:"1px solid rgba(212,175,55,0.2)",borderRadius:"12px",padding:"16px 20px",marginTop:"12px",
        }},
          React.createElement("p", {style:{margin:0,fontSize:"15px",lineHeight:"1.7",color:C.textDark,direction:props.langPref==="arabic"?"rtl":"ltr"}}, msg)
        ),
        React.createElement("div", {style:{display:"flex",gap:"10px",marginTop:"20px",justifyContent:"flex-end"}},
          React.createElement("button", {onClick:regen,className:"btn-sm",style:{padding:"8px 16px",borderRadius:"8px",border:"1px solid #d1d5db",background:"transparent",color:C.textMuted,cursor:"pointer",fontSize:"13px",fontWeight:"600"}}, "\u21BB Regenerate"),
          React.createElement("button", {onClick:copyMsg,className:"btn-gold btn-sm",style:{padding:"8px 16px",borderRadius:"8px",border:"none",background:C.goldMetal,color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600"}}, copied ? "\u2713 Copied!" : "\u2398 Copy Message")
        )
      )
    )
  );
}

// ============================================================================
// DASHBOARD PAGE
// ============================================================================

function DashboardPage(props) {
  var contacts = props.contacts;
  var today = todayMisri();
  var _mc = useState(null), msgContact = _mc[0], setMsgContact = _mc[1];

  var todayBdays = contacts.filter(function(c) {
    return c.misri_day === today.day && c.misri_month === today.month;
  });

  var upcoming = useMemo(function() {
    var results = [];
    for (var i = 1; i <= 30; i++) {
      var fd = getMisriDateInNDays(i);
      contacts.forEach(function(c) {
        if (c.misri_day === fd.day && c.misri_month === fd.month) results.push(Object.assign({},c,{daysUntil:i}));
      });
    }
    return results;
  }, [contacts]);

  var gregStr = new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});

  return React.createElement("div", null,
    // Hero card
    React.createElement("div", { style:{
      background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",
      borderRadius:"16px",padding:"32px",color:"#fff",position:"relative",overflow:"hidden",
      marginBottom:"28px",border:"1px solid rgba(212,175,55,0.3)",boxShadow:"0 8px 32px rgba(10,22,40,0.4)",
    }},
      React.createElement("div",{className:"fatimid-bg"}),
      React.createElement("div", {style:{position:"relative",zIndex:2,display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"16px"}},
        React.createElement("div", null,
          React.createElement("div", {style:{fontSize:"12px",textTransform:"uppercase",letterSpacing:"2px",color:C.goldLight,marginBottom:"8px",fontWeight:"600"}}, "Today\u2019s Date"),
          React.createElement("div", {style:{fontSize:"32px",fontWeight:"800",color:C.gold,marginBottom:"4px"}}, formatMisriDate(today.day,today.month,today.year)),
          React.createElement("div", {style:{fontSize:"14px",color:"rgba(255,255,255,0.5)"}}, gregStr)
        ),
        React.createElement("div", {style:{background:"rgba(212,175,55,0.12)",borderRadius:"12px",padding:"16px 24px",border:"1px solid rgba(212,175,55,0.2)",textAlign:"center"}},
          React.createElement("div", {style:{fontSize:"36px",fontWeight:"800",color:C.gold}}, todayBdays.length),
          React.createElement("div", {style:{fontSize:"11px",color:"rgba(255,255,255,0.5)",textTransform:"uppercase",letterSpacing:"1px"}}, "Birthday"+(todayBdays.length!==1?"s":"")+" Today")
        )
      )
    ),

    // Today's birthdays card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold,display:"flex",alignItems:"center",gap:"10px"}},
        React.createElement("span", null, "\uD83C\uDF82"),
        React.createElement("span", {style:{fontSize:"16px",fontWeight:"600"}}, "Today\u2019s Misri Birthdays")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        todayBdays.length === 0
          ? React.createElement("div", {style:{textAlign:"center",padding:"32px 0",color:C.textMuted}},
              React.createElement("div", {style:{fontSize:"40px",marginBottom:"12px"}}, "\uD83C\uDF19"),
              React.createElement("p", {style:{margin:0}}, "No birthdays today. Check back tomorrow!")
            )
          : todayBdays.map(function(ct) {
              return React.createElement("div", {key:ct.id, style:{
                display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px",
                background:"linear-gradient(90deg, rgba(212,175,55,0.06), transparent)",
                borderRadius:"10px",marginBottom:"8px",border:"1px solid rgba(212,175,55,0.15)",
              }},
                React.createElement("div", null,
                  React.createElement("div", {style:{fontWeight:"700",fontSize:"16px",color:C.textDark}}, ct.name),
                  React.createElement("div", {style:{fontSize:"13px",color:C.textMuted,marginTop:"2px"}}, ct.relationship+" \u2022 "+formatMisriDate(ct.misri_day,ct.misri_month))
                ),
                React.createElement("button", {onClick:function(){setMsgContact(ct);},className:"btn-gold btn-sm",style:{
                  padding:"8px 16px",borderRadius:"8px",border:"none",background:C.goldMetal,color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600",
                }}, "\uD83C\uDF89 Send Wishes")
              );
            })
      )
    ),

    // Upcoming card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold,display:"flex",justifyContent:"space-between",alignItems:"center"}},
        React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"10px"}},
          React.createElement("span", null, "\u2B50"),
          React.createElement("span", {style:{fontSize:"16px",fontWeight:"600"}}, "Upcoming (Next 30 Days)")
        ),
        React.createElement("span", {style:tag(C.goldLight)}, upcoming.length+" upcoming")
      ),
      upcoming.length === 0
        ? React.createElement("div", {style:{textAlign:"center",padding:"32px",color:C.textMuted}}, "No upcoming birthdays in the next 30 days.")
        : upcoming.map(function(ct,i) {
            return React.createElement("div", {key:ct.id+"_"+ct.daysUntil, className:"contact-row", style:{
              display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 20px",
              borderBottom:"1px solid rgba(0,0,0,0.05)",
            }},
              React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"14px"}},
                React.createElement("div", {style:{
                  width:"42px",height:"42px",borderRadius:"10px",
                  background:"linear-gradient(135deg, "+C.navy+", "+C.navyMid+")",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  color:C.gold,fontWeight:"700",fontSize:"14px",
                }}, ct.misri_day),
                React.createElement("div", null,
                  React.createElement("div", {style:{fontWeight:"600",color:C.textDark}}, ct.name),
                  React.createElement("div", {style:{fontSize:"12px",color:C.textMuted}}, formatMisriDate(ct.misri_day,ct.misri_month)+" \u2022 "+ct.relationship)
                )
              ),
              React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"12px"}},
                React.createElement("span", {style:tag(C.goldDark)}, "in "+ct.daysUntil+" day"+(ct.daysUntil!==1?"s":"")),
                React.createElement("button", {onClick:function(){setMsgContact(ct);},className:"btn-sm",style:{
                  padding:"6px 12px",borderRadius:"8px",border:"1px solid rgba(212,175,55,0.3)",
                  background:"transparent",color:C.gold,cursor:"pointer",fontSize:"12px",fontWeight:"600",
                }}, "\u2709 Message")
              )
            );
          })
    ),

    msgContact && React.createElement(MessageModal, { contact:msgContact, langPref:props.langPref, onClose:function(){setMsgContact(null);} })
  );
}

// ============================================================================
// CONTACTS PAGE
// ============================================================================

function ContactsPage(props) {
  var contacts = props.contacts;
  var _sm = useState(false), showModal = _sm[0], setShowModal = _sm[1];
  var _ec = useState(null), editing = _ec[0], setEditing = _ec[1];
  var _mc = useState(null), msgC = _mc[0], setMsgC = _mc[1];
  var _sr = useState(""), search = _sr[0], setSearch = _sr[1];
  var today = todayMisri();

  var filtered = contacts.filter(function(c) {
    var q = search.toLowerCase();
    return c.name.toLowerCase().indexOf(q)!==-1 || c.relationship.toLowerCase().indexOf(q)!==-1;
  });

  function handleSave(contact) {
    if (editing) props.onEdit(contact); else props.onAdd(contact);
    setShowModal(false); setEditing(null);
  }

  return React.createElement("div", null,
    React.createElement("div", {style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"24px",flexWrap:"wrap",gap:"12px"}},
      React.createElement("div", null,
        React.createElement("h2", {style:{margin:0,fontSize:"24px",fontWeight:"700",color:C.textDark}}, "Contacts"),
        React.createElement("p", {style:{margin:"4px 0 0",fontSize:"14px",color:C.textMuted}}, contacts.length+" people in your birthday list")
      ),
      React.createElement("button", {onClick:function(){setEditing(null);setShowModal(true);},className:"btn-gold btn-sm",style:{
        padding:"8px 16px",borderRadius:"8px",border:"none",background:C.goldMetal,color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600",display:"inline-flex",alignItems:"center",gap:"6px",
      }}, "+ Add Contact")
    ),
    // Search
    React.createElement("div", {style:{marginBottom:"20px"}},
      React.createElement("input", {
        type:"text",placeholder:"Search by name or relationship\u2026",value:search,
        onChange:function(e){setSearch(e.target.value);},
        style:{width:"100%",padding:"12px 18px",borderRadius:"10px",background:C.white,border:"1px solid rgba(212,175,55,0.2)",fontSize:"14px",boxSizing:"border-box"}
      })
    ),
    // List
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold,display:"flex",justifyContent:"space-between",alignItems:"center"}},
        React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "All Contacts"),
        React.createElement("span", {style:{fontSize:"12px",color:C.goldLight}}, filtered.length+" shown")
      ),
      filtered.length === 0
        ? React.createElement("div", {style:{textAlign:"center",padding:"48px 24px",color:C.textMuted}},
            React.createElement("div",{style:{fontSize:"48px",marginBottom:"12px"}}, "\uD83D\uDCC7"),
            React.createElement("p",{style:{margin:"0 0 16px"}}, contacts.length===0?"No contacts yet. Add your first one!":"No contacts match your search."),
            contacts.length===0 && React.createElement("button",{onClick:function(){setShowModal(true);},className:"btn-gold btn-sm",style:{padding:"8px 16px",borderRadius:"8px",border:"none",background:C.goldMetal,color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600"}}, "+ Add Your First Contact")
          )
        : filtered.map(function(ct) {
            var isToday = ct.misri_day===today.day && ct.misri_month===today.month;
            var avatarBg = isToday ? "linear-gradient(135deg, "+C.gold+", "+C.goldDark+")" : "linear-gradient(135deg, "+C.navy+", "+C.navyMid+")";
            return React.createElement("div", {key:ct.id, className:"contact-row", style:{
              display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 20px",
              borderBottom:"1px solid rgba(0,0,0,0.05)",background:isToday?"rgba(212,175,55,0.06)":"transparent",
            }},
              React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"16px",flex:1,minWidth:0}},
                React.createElement("div", {style:{width:"48px",height:"48px",borderRadius:"12px",background:avatarBg,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}},
                  React.createElement("span", {style:{color:isToday?C.navy:C.gold,fontWeight:"800",fontSize:"16px"}}, ct.name.charAt(0).toUpperCase())
                ),
                React.createElement("div", {style:{minWidth:0}},
                  React.createElement("div", {style:{fontWeight:"600",fontSize:"15px",color:C.textDark,display:"flex",alignItems:"center",gap:"8px"}},
                    React.createElement("span", {style:{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}, ct.name),
                    isToday && React.createElement("span", {style:{fontSize:"16px"}}, "\uD83C\uDF82")
                  ),
                  React.createElement("div", {style:{fontSize:"13px",color:C.textMuted,marginTop:"2px"}},
                    React.createElement("span", {style:tag(C.navyMid)}, ct.relationship),
                    " \u2022 ",
                    React.createElement("span", {style:{color:C.goldDark,fontWeight:"600"}}, formatMisriDate(ct.misri_day,ct.misri_month)),
                    " \u2022 ",
                    new Date(ct.gregorian_dob+"T00:00:00").toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})
                  )
                )
              ),
              React.createElement("div", {style:{display:"flex",gap:"6px",flexShrink:0}},
                React.createElement("button",{onClick:function(){setMsgC(ct);},className:"btn-sm",title:"Message",style:{padding:"6px 10px",borderRadius:"8px",border:"1px solid rgba(212,175,55,0.3)",background:"transparent",color:C.gold,cursor:"pointer",fontSize:"14px"}}, "\u2709"),
                React.createElement("button",{onClick:function(){setEditing(ct);setShowModal(true);},className:"btn-sm",title:"Edit",style:{padding:"6px 10px",borderRadius:"8px",border:"1px solid rgba(212,175,55,0.3)",background:"transparent",color:C.gold,cursor:"pointer",fontSize:"14px"}}, "\u270E"),
                React.createElement("button",{onClick:function(){props.onDelete(ct.id);},className:"btn-sm",title:"Delete",style:{padding:"6px 10px",borderRadius:"6px",border:"1px solid rgba(220,38,38,0.3)",background:"rgba(220,38,38,0.08)",color:C.danger,cursor:"pointer",fontSize:"14px"}}, "\uD83D\uDDD1")
              )
            );
          })
    ),
    showModal && React.createElement(ContactModal, {contact:editing, onSave:handleSave, onClose:function(){setShowModal(false);setEditing(null);}}),
    msgC && React.createElement(MessageModal, {contact:msgC, langPref:props.langPref, onClose:function(){setMsgC(null);}})
  );
}

// ============================================================================
// SETTINGS PAGE
// ============================================================================

function ToggleSwitch(props) {
  return React.createElement("button", {
    onClick: props.onToggle,
    style:{width:"48px",height:"26px",borderRadius:"13px",border:"none",background:props.on?C.gold:"#d1d5db",position:"relative",cursor:"pointer",transition:"background 0.25s",flexShrink:0}
  },
    React.createElement("div", {className:"toggle-knob",style:{width:"20px",height:"20px",borderRadius:"50%",background:"#fff",position:"absolute",top:"3px",left:props.on?"25px":"3px",boxShadow:"0 1px 3px rgba(0,0,0,0.2)"}})
  );
}

function SettingsPage(props) {
  var _ns = useState(null), notifStatus = _ns[0], setNotifStatus = _ns[1];

  useEffect(function() {
    if (typeof Notification !== "undefined") setNotifStatus(Notification.permission);
  }, []);

  function requestPermission() {
    if (typeof Notification === "undefined") { setNotifStatus("denied"); return; }
    setNotifStatus("requesting");
    Notification.requestPermission().then(function(r) {
      setNotifStatus(r);
      if (r === "granted") {
        props.setNotifications(function(p) { return Object.assign({},p,{warasDay:true}); });
        new Notification("\u0646\u0648\u0631 \u0627\u0644\u0648\u0650\u0644\u0627\u062F\u0629 \u2014 N\u016Br al-Wil\u0101dah", {
          body: "Waras notifications enabled! You\u2019ll be reminded on the day of each Misri birthday.",
        });
      }
    }).catch(function(){ setNotifStatus("denied"); });
  }

  function toggleN(key) {
    props.setNotifications(function(p) { var u = Object.assign({},p); u[key]=!u[key]; return u; });
  }

  var langOpts = [
    {value:"english",label:"English Only",desc:"Standard English messages"},
    {value:"mixed",label:"English + Lisan-ud-Dawat",desc:"Mixed with Bohra phrases"},
    {value:"arabic",label:"Arabic / \u0627\u0644\u0639\u0631\u0628\u064A\u0629",desc:"Arabic script messages"},
  ];
  var notifOpts = [
    {key:"warasDay",label:"Waras Day Alert",desc:"Notify me at the start of each contact\u2019s Misri birthday",icon:"\uD83C\uDF82"},
    {key:"warasEve",label:"Day Before Reminder",desc:"Get a reminder the evening before a waras",icon:"\uD83C\uDF19"},
    {key:"warasWeek",label:"Weekly Digest",desc:"Summary of upcoming waras for the next 7 days",icon:"\uD83D\uDCCB"},
  ];

  return React.createElement("div", null,
    React.createElement("h2", {style:{margin:"0 0 8px",fontSize:"24px",fontWeight:"700",color:C.textDark}}, "Settings"),
    React.createElement("p", {style:{margin:"0 0 28px",fontSize:"14px",color:C.textMuted}}, "Customize your experience"),

    // Account card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold}},
        React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "Account")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        React.createElement("div", {style:{display:"grid",gridTemplateColumns:"140px 1fr",gap:"12px",fontSize:"14px"}},
          React.createElement("span", {style:{color:C.textMuted,fontWeight:"600"}}, "ITS ID"),
          React.createElement("span", null, props.user.its_id),
          React.createElement("span", {style:{color:C.textMuted,fontWeight:"600"}}, "Name"),
          React.createElement("span", null, props.user.name),
          React.createElement("span", {style:{color:C.textMuted,fontWeight:"600"}}, "Email"),
          React.createElement("span", null, props.user.email)
        )
      )
    ),

    // Waras notifications card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.3)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, #1a2d5a 100%)",color:C.gold,display:"flex",justifyContent:"space-between",alignItems:"center"}},
        React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"10px"}},
          React.createElement("span", null, "\uD83D\uDD14"),
          React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "Waras Day Notifications")
        ),
        notifStatus==="granted" && React.createElement("span", {style:tag(C.success)}, "Active")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        notifStatus !== "granted"
          ? React.createElement("div", {style:{textAlign:"center",padding:"16px 0"}},
              React.createElement("div",{style:{fontSize:"36px",marginBottom:"12px"}},"\uD83D\uDD14"),
              React.createElement("p",{style:{margin:"0 0 6px",fontSize:"15px",fontWeight:"600",color:C.textDark}}, "Enable Waras Reminders"),
              React.createElement("p",{style:{margin:"0 0 20px",fontSize:"13px",color:C.textMuted,maxWidth:"360px",marginLeft:"auto",marginRight:"auto",lineHeight:"1.6"}},
                "Get notified on the day of each Misri birthday so you never miss wishing your loved ones on their waras."
              ),
              notifStatus==="denied"
                ? React.createElement("div",{style:{fontSize:"13px",color:C.danger,padding:"10px 16px",background:"rgba(220,38,38,0.06)",borderRadius:"8px",border:"1px solid rgba(220,38,38,0.15)"}},
                    "Notifications are blocked. Please enable them in your browser settings."
                  )
                : React.createElement("button",{onClick:requestPermission,disabled:notifStatus==="requesting",className:"btn-gold btn-sm",style:{
                    padding:"10px 20px",borderRadius:"8px",border:"none",background:C.goldMetal,color:C.navy,cursor:"pointer",fontSize:"13px",fontWeight:"600",
                  }}, notifStatus==="requesting"?"Requesting\u2026":"\uD83D\uDD14  Enable Notifications")
            )
          : React.createElement("div", null,
              notifOpts.map(function(opt,i) {
                return React.createElement("div", {key:opt.key,style:{
                  display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 0",
                  borderBottom:i<notifOpts.length-1?"1px solid rgba(0,0,0,0.06)":"none",
                }},
                  React.createElement("div",{style:{display:"flex",alignItems:"center",gap:"14px"}},
                    React.createElement("span",{style:{fontSize:"22px"}}, opt.icon),
                    React.createElement("div", null,
                      React.createElement("div",{style:{fontWeight:"600",fontSize:"14px",color:C.textDark}}, opt.label),
                      React.createElement("div",{style:{fontSize:"12px",color:C.textMuted,marginTop:"2px"}}, opt.desc)
                    )
                  ),
                  React.createElement(ToggleSwitch, {on:props.notifications[opt.key], onToggle:function(){toggleN(opt.key);}})
                );
              }),
              React.createElement("div",{style:{marginTop:"16px",padding:"12px 16px",background:"rgba(212,175,55,0.06)",borderRadius:"10px",border:"1px solid rgba(212,175,55,0.15)",fontSize:"13px",color:C.textMuted,lineHeight:"1.6"}},
                React.createElement("strong",{style:{color:C.goldDark}}, "How it works: "),
                "When the app is open, it checks today\u2019s Misri date against your contacts and sends a browser notification for each waras match."
              )
            )
      )
    ),

    // Language card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold}},
        React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "Language & Messages")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        React.createElement("label",{style:{display:"block",fontSize:"13px",fontWeight:"600",color:C.textDark,marginBottom:"10px"}}, "Birthday Message Language"),
        React.createElement("div",{style:{display:"flex",gap:"10px",flexWrap:"wrap"}},
          langOpts.map(function(opt) {
            var active = props.langPref === opt.value;
            return React.createElement("button", {key:opt.value,onClick:function(){props.setLangPref(opt.value);}, style:{
              flex:"1 1 150px",padding:"14px 16px",borderRadius:"10px",cursor:"pointer",textAlign:"left",
              border:active?"2px solid "+C.gold:"2px solid #e5e7eb",
              background:active?"rgba(212,175,55,0.06)":C.white,
            }},
              React.createElement("div",{style:{fontWeight:"600",fontSize:"14px",color:C.textDark}}, opt.label),
              React.createElement("div",{style:{fontSize:"12px",color:C.textMuted,marginTop:"2px"}}, opt.desc)
            );
          })
        )
      )
    ),

    // Timezone card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold}},
        React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "Timezone")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        React.createElement("select", {value:props.timezone,onChange:function(e){props.setTimezone(e.target.value);},style:{width:"100%",maxWidth:"320px",padding:"10px 14px",border:"1px solid #d1d5db",borderRadius:"8px",fontSize:"14px",cursor:"pointer",boxSizing:"border-box"}},
          ["America/New_York","America/Chicago","America/Denver","America/Los_Angeles","Asia/Kolkata","Asia/Karachi","Asia/Dubai","Europe/London","Africa/Nairobi","Asia/Kuala_Lumpur","Australia/Sydney"].map(function(tz){
            return React.createElement("option",{key:tz,value:tz},tz);
          })
        )
      )
    ),

    // About card
    React.createElement("div", {style:{background:C.white,borderRadius:"14px",border:"1px solid rgba(212,175,55,0.15)",boxShadow:"0 4px 20px rgba(0,0,0,0.06)",overflow:"hidden",marginBottom:"24px"}},
      React.createElement("div", {style:{padding:"20px 24px",background:"linear-gradient(135deg, "+C.navy+" 0%, "+C.navyMid+" 100%)",color:C.gold}},
        React.createElement("span", {style:{fontSize:"14px",fontWeight:"600"}}, "About Misri Calendar")
      ),
      React.createElement("div", {style:{padding:"24px"}},
        React.createElement("p",{style:{margin:"0 0 8px",fontSize:"14px",lineHeight:"1.7",color:C.textDark}},
          "The Misri (Fatimid) calendar is a fixed tabular lunar calendar followed by the Dawoodi Bohra community. It uses a 30-year cycle with 11 leap years where Zilhaj has 30 days instead of 29."
        ),
        React.createElement("p",{style:{margin:0,fontSize:"13px",color:C.textMuted}},
          "Leap years in each 30-year cycle: 2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29"
        )
      )
    )
  );
}

// ============================================================================
// MAIN APP
// ============================================================================

function App() {
  var demoUser = {id:"u_30000001",its_id:"30000001",name:"Mumineen User",email:"30000001@its52.com"};
  var _u = useState(function(){try{return JSON.parse(localStorage.getItem("nw_user"))||demoUser;}catch(e){return demoUser;}}), user=_u[0], setUser=_u[1];
  var _t = useState(function(){return localStorage.getItem("nw_token")||"demo";}), token=_t[0], setToken=_t[1];
  var _pg = useState("dashboard"), page=_pg[0], setPage=_pg[1];

  var todayM = todayMisri();
  var sampleContacts = [
    {id:"c_1",name:"Husain bhai Fakhruddin",relationship:"Family",gregorian_dob:"1990-03-15",misri_day:todayM.day,misri_month:todayM.month,misri_year_born:1410,notes:"",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_2",name:"Sakina ben Hatim",relationship:"Family",gregorian_dob:"1995-07-22",misri_day:todayM.day,misri_month:todayM.month,misri_year_born:1416,notes:"",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_3",name:"Taher bhai Saifuddin",relationship:"Friend",gregorian_dob:"1988-11-05",misri_day:Math.min(todayM.day+3,29),misri_month:todayM.month,misri_year_born:1409,notes:"",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_4",name:"Maryam ben Qutbuddin",relationship:"Community",gregorian_dob:"2000-01-10",misri_day:Math.min(todayM.day+7,29),misri_month:todayM.month,misri_year_born:1420,notes:"Jamaat volunteer",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_5",name:"Abdeali bhai Burhanuddin",relationship:"Teacher/Mentor",gregorian_dob:"1975-05-30",misri_day:Math.min(todayM.day+12,30),misri_month:todayM.month,misri_year_born:1395,notes:"Quran teacher",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_6",name:"Fatema ben Najmuddin",relationship:"Family",gregorian_dob:"1998-09-18",misri_day:5,misri_month:todayM.month===12?1:todayM.month+1,misri_year_born:1419,notes:"",created_at:"2025-01-01",updated_at:"2025-01-01"},
    {id:"c_7",name:"Juzer bhai Shabbir",relationship:"Colleague",gregorian_dob:"1992-12-01",misri_day:15,misri_month:todayM.month===12?1:todayM.month+1,misri_year_born:1413,notes:"",created_at:"2025-01-01",updated_at:"2025-01-01"},
  ];

  var _ct = useState([]), contacts=_ct[0], setContacts=_ct[1];
  var _lp = useState(function(){return localStorage.getItem("nw_lang")||"mixed";}), langPref=_lp[0], setLangPref=_lp[1];
  var _tz = useState(function(){try{return Intl.DateTimeFormat().resolvedOptions().timeZone;}catch(e){return "America/New_York";}}), timezone=_tz[0], setTimezone=_tz[1];
  var _nf = useState(function(){try{return JSON.parse(localStorage.getItem("nw_notifs"))||{warasDay:false,warasEve:false,warasWeek:false};}catch(e){return{warasDay:false,warasEve:false,warasWeek:false};}}), notifications=_nf[0], setNotifications=_nf[1];

  useEffect(function(){
    if(user){var s=loadContacts(user.id);if(s.length>0){setContacts(s);}else{setContacts(sampleContacts);saveContacts(user.id,sampleContacts);}}
  },[user]);

  useEffect(function(){localStorage.setItem("nw_lang",langPref);},[langPref]);
  useEffect(function(){localStorage.setItem("nw_tz",timezone);},[timezone]);
  useEffect(function(){localStorage.setItem("nw_notifs",JSON.stringify(notifications));},[notifications]);

  // Waras notification check
  useEffect(function(){
    if(!user||!notifications.warasDay) return;
    function check(){
      if(typeof Notification==="undefined"||Notification.permission!=="granted") return;
      var td=todayMisri(); var lk=td.year+"-"+td.month+"-"+td.day;
      if(localStorage.getItem("nw_last_notif")===lk) return;
      var tb=contacts.filter(function(c){return c.misri_day===td.day&&c.misri_month===td.month;});
      if(tb.length>0){
        new Notification("\uD83C\uDF19 Waras Mubarak!",{body:"Today is the Misri birthday of: "+tb.map(function(c){return c.name;}).join(", "),tag:"waras-"+lk});
        localStorage.setItem("nw_last_notif",lk);
      }
      if(notifications.warasEve){
        var tmr=getMisriDateInNDays(1);
        var tmrB=contacts.filter(function(c){return c.misri_day===tmr.day&&c.misri_month===tmr.month;});
        if(tmrB.length>0) new Notification("\uD83C\uDF19 Waras Reminder \u2014 Tomorrow",{body:"Tomorrow is the Misri birthday of: "+tmrB.map(function(c){return c.name;}).join(", "),tag:"waras-eve-"+lk});
      }
    }
    check(); var iv=setInterval(check,3600000); return function(){clearInterval(iv);};
  },[user,contacts,notifications]);

  function handleLogin(u,t){setUser(u);setToken(t);localStorage.setItem("nw_user",JSON.stringify(u));localStorage.setItem("nw_token",t);}
  function handleLogout(){setUser(null);setToken(null);setContacts([]);localStorage.removeItem("nw_user");localStorage.removeItem("nw_token");setPage("dashboard");}
  function addContact(c){var u=[].concat(contacts,[c]);setContacts(u);saveContacts(user.id,u);}
  function editContact(c){var u=contacts.map(function(x){return x.id===c.id?c:x;});setContacts(u);saveContacts(user.id,u);}
  function deleteContact(id){var u=contacts.filter(function(x){return x.id!==id;});setContacts(u);saveContacts(user.id,u);}

  if(!user) return React.createElement(LoginPage,{onLogin:handleLogin});

  var navItems = [
    {id:"dashboard",icon:"\u25A3",label:"Dashboard"},
    {id:"contacts",icon:"\u263A",label:"Contacts"},
    {id:"settings",icon:"\u2699",label:"Settings"},
  ];

  return React.createElement("div", {style:{display:"flex",minHeight:"100vh"}},
    // Sidebar
    React.createElement("aside", {style:{
      width:"240px",background:C.navyLight,borderRight:"1px solid rgba(212,175,55,0.15)",
      display:"flex",flexDirection:"column",position:"fixed",top:0,left:0,bottom:0,zIndex:50,
    }},
      React.createElement("div", {style:{padding:"24px 20px",borderBottom:"1px solid rgba(212,175,55,0.15)"}},
        React.createElement("div", {style:{display:"flex",alignItems:"center",gap:"10px"}},
          React.createElement("div", {style:{width:"36px",height:"36px",borderRadius:"8px",background:C.goldMetal,display:"flex",alignItems:"center",justifyContent:"center"}},
            React.createElement("span", {style:{color:C.navy,fontSize:"18px"}}, "\uD83C\uDF19")
          ),
          React.createElement("div", null,
            React.createElement("div", {style:{color:C.gold,fontWeight:"700",fontSize:"16px",lineHeight:"1.2"}}, "\u0646\u0648\u0631 \u0627\u0644\u0648\u0650\u0644\u0627\u062F\u0629"),
            React.createElement("div", {style:{color:"rgba(255,255,255,0.4)",fontSize:"11px"}}, "N\u016Br al-Wil\u0101dah")
          )
        )
      ),
      React.createElement("nav", {style:{padding:"16px 12px",flex:1}},
        navItems.map(function(item) {
          var active = page===item.id;
          return React.createElement("button", {
            key:item.id, className:"nav-btn",
            onClick:function(){setPage(item.id);},
            style:{
              display:"flex",alignItems:"center",gap:"12px",padding:"12px 16px",borderRadius:"10px",
              color:active?C.gold:"rgba(255,255,255,0.6)",
              background:active?"rgba(212,175,55,0.1)":"transparent",
              border:active?"1px solid rgba(212,175,55,0.2)":"1px solid transparent",
              cursor:"pointer",fontSize:"14px",fontWeight:active?"600":"400",
              marginBottom:"4px",width:"100%",textAlign:"left",
            }
          },
            React.createElement("span",{style:{fontSize:"16px",width:"20px",textAlign:"center"}},item.icon),
            item.label
          );
        })
      ),
      React.createElement("div", {style:{padding:"16px",borderTop:"1px solid rgba(212,175,55,0.1)"}},
        React.createElement("div",{style:{fontSize:"12px",color:"rgba(255,255,255,0.4)",marginBottom:"8px"}}, "ITS: "+user.its_id),
        React.createElement("button", {
          onClick:handleLogout, className:"nav-btn",
          style:{display:"flex",alignItems:"center",gap:"12px",padding:"12px 16px",borderRadius:"10px",
            color:"rgba(255,255,255,0.5)",background:"transparent",border:"1px solid transparent",
            cursor:"pointer",fontSize:"14px",width:"100%",textAlign:"left"}
        }, "\u2190 Sign Out")
      )
    ),

    // Main
    React.createElement("main", {style:{marginLeft:"240px",flex:1,minHeight:"100vh",background:C.cream,position:"relative"}},
      React.createElement("div", {style:{background:C.navy,padding:"16px 32px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"2px solid "+C.gold}},
        React.createElement("div",{style:{color:C.gold,fontWeight:"600",fontSize:"15px"}},
          page==="dashboard"?"Dashboard":page==="contacts"?"Contacts & Birthdays":"Settings"
        ),
        React.createElement("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},
          React.createElement("span",{style:{fontSize:"13px",color:"rgba(255,255,255,0.5)"}}, formatMisriDate(todayMisri().day,todayMisri().month,todayMisri().year)),
          React.createElement("div",{style:{width:"32px",height:"32px",borderRadius:"8px",background:"rgba(212,175,55,0.15)",display:"flex",alignItems:"center",justifyContent:"center",color:C.gold,fontWeight:"700",fontSize:"13px"}}, user.name.charAt(0))
        )
      ),
      React.createElement("div", {style:{position:"relative"}},
        React.createElement("div",{className:"fatimid-bg-light"}),
        React.createElement("div", {style:{padding:"32px",maxWidth:"1100px",margin:"0 auto",position:"relative",zIndex:1}},
          page==="dashboard" && React.createElement(DashboardPage, {contacts:contacts,langPref:langPref}),
          page==="contacts" && React.createElement(ContactsPage, {contacts:contacts,onAdd:addContact,onEdit:editContact,onDelete:deleteContact,langPref:langPref}),
          page==="settings" && React.createElement(SettingsPage, {
            langPref:langPref,setLangPref:setLangPref,timezone:timezone,setTimezone:setTimezone,
            user:user,notifications:notifications,setNotifications:setNotifications,
          })
        )
      )
    )
  );
}

// ============================================================================
// MOUNT
// ============================================================================

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
